/**
 * Example backend security layer (Node + Express)
 * Use this when you deploy — pure frontend CANNOT fully hide source.
 *
 * npm i express helmet express-rate-limit compression
 *
 * Real protections:
 * - Helmet (headers)
 * - Rate limiting
 * - No directory listing
 * - Serve minified / hashed assets only
 * - Optional: auth for private routes
 * - Never put secrets in frontend JS
 */

const express = require('express');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const compression = require('compression');

const app = express();
const PORT = process.env.PORT || 3000;

// Security headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "https://cdnjs.cloudflare.com", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://cdnjs.cloudflare.com", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

// Rate limit
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests' },
}));

app.use(compression());

// Block common probing paths
app.use((req, res, next) => {
  const blocked = [
    '/.env', '/.git', '/package.json', '/node_modules',
    '/wp-admin', '/phpmyadmin', '/.htaccess', '/config'
  ];
  if (blocked.some(p => req.path.startsWith(p))) {
    return res.status(404).end();
  }
  next();
});

// Serve static portfolio (prefer built/minified assets in production)
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '7d',
  etag: true,
  index: 'index.html',
  // Do not expose directory listings
  setHeaders: (res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  },
}));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Secure static server on :${PORT}`);
});
