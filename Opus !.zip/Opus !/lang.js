/* CPS language switch.
   English is the default. Choosing বাংলা translates the whole website (Google Translate engine).
   The engine is loaded only when Bangla is active, so English visitors never load it.
   The choice is stored in the googtrans cookie, so it follows the visitor across every page. */
(function () {
  'use strict';

  var COOKIE = 'googtrans';
  var HOST = location.hostname;
  var CAN_SCOPE_DOMAIN = HOST && HOST !== 'localhost' && HOST.indexOf('.') > -1 && !/^[\d.]+$/.test(HOST);

  function currentLang() {
    try {
      var m = document.cookie.match(/(?:^|;\s*)googtrans=([^;]*)/);
      if (m && decodeURIComponent(m[1]).split('/')[2] === 'bn') return 'bn';
    } catch (e) { /* cookies blocked: stay in English */ }
    return 'en';
  }

  function writeCookie(suffix) {
    try {
      document.cookie = COOKIE + suffix + '; path=/';
      if (CAN_SCOPE_DOMAIN) document.cookie = COOKIE + suffix + '; path=/; domain=' + HOST;
    } catch (e) { /* ignore */ }
  }

  function setLang(lang) {
    if (lang === currentLang()) return;
    if (lang === 'bn') writeCookie('=/en/bn');
    else writeCookie('=; expires=Thu, 01 Jan 1970 00:00:00 GMT');
    location.reload();
  }

  function paint() {
    var lang = currentLang();
    document.documentElement.setAttribute('lang', lang);
    var buttons = document.querySelectorAll('.lang-btn');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].setAttribute('aria-pressed', buttons[i].getAttribute('data-lang') === lang ? 'true' : 'false');
    }
  }

  function loadBanglaFont() {
    if (document.getElementById('cps-bn-font')) return;
    var link = document.createElement('link');
    link.id = 'cps-bn-font';
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap';
    document.head.appendChild(link);
  }

  function loadTranslator() {
    if (document.getElementById('cps-gt-loader')) return;
    var holder = document.createElement('div');
    holder.id = 'google_translate_element';
    holder.className = 'notranslate';
    holder.setAttribute('translate', 'no');
    document.body.appendChild(holder);

    window.cpsGoogleTranslateInit = function () {
      try {
        new window.google.translate.TranslateElement(
          { pageLanguage: 'en', includedLanguages: 'bn,en', autoDisplay: false },
          'google_translate_element'
        );
      } catch (e) { /* engine unavailable (offline): page stays in English */ }
    };

    var s = document.createElement('script');
    s.id = 'cps-gt-loader';
    s.src = 'https://translate.google.com/translate_a/element.js?cb=cpsGoogleTranslateInit';
    s.async = true;
    document.head.appendChild(s);
  }

  function init() {
    paint();
    if (currentLang() === 'bn') {
      loadBanglaFont();
      loadTranslator();
    }
    var buttons = document.querySelectorAll('.lang-btn');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener('click', function () {
        setLang(this.getAttribute('data-lang'));
      });
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
