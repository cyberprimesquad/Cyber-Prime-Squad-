/* Stenographer: hide a text message inside a picture and read it back.
   Everything runs in the browser. Nothing is uploaded.

   Hidden layout. Each bit is stored in the least significant bit of one red, green or
   blue sample (alpha is never touched). Bits run most significant first.
     4 bytes  magic "STG1"           tells a real message apart from ordinary pixels
     4 bytes  length N (big-endian)  number of UTF-8 bytes that follow
     N bytes  the message, UTF-8     any language, including Bangla and emoji
*/
(function () {
  'use strict';

  var MAGIC = [0x53, 0x54, 0x47, 0x31]; // "STG1"
  var HEADER = 8;                        // magic + length
  var MAX_PIXELS = 30000000;             // keeps very large pictures from freezing the page

  function $(id) { return document.getElementById(id); }

  function setStatus(id, msg, kind) {
    var el = $(id);
    el.textContent = msg || '';
    el.className = 'st-status' + (kind ? ' ' + kind : '');
  }

  /* ---------- tabs ---------- */
  var tabs = document.querySelectorAll('.st-tab');

  function showTab(name) {
    for (var i = 0; i < tabs.length; i++) {
      var key = tabs[i].getAttribute('data-tab');
      var on = key === name;
      tabs[i].setAttribute('aria-selected', on ? 'true' : 'false');
      tabs[i].tabIndex = on ? 0 : -1;
      $('panel-' + key).hidden = !on;
    }
  }

  for (var t = 0; t < tabs.length; t++) {
    tabs[t].addEventListener('click', function () {
      showTab(this.getAttribute('data-tab'));
    });
    tabs[t].addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
      var next = this.getAttribute('data-tab') === 'encode' ? 'decode' : 'encode';
      showTab(next);
      $('tab-' + next).focus();
      e.preventDefault();
    });
  }

  /* ---------- pictures ---------- */

  // Opens a picture the user chose. Returns the image and its object URL (used for the preview).
  function openFile(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () { resolve({ img: img, url: url }); };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error('That file could not be opened as a picture. Try a PNG, JPG or WebP image.'));
      };
      img.src = url;
    });
  }

  // Draws the picture at its real size onto an opaque white canvas. Transparent pixels would
  // otherwise be changed when the PNG is flattened, and the hidden bits would be lost.
  function toCanvas(img) {
    var w = img.naturalWidth, h = img.naturalHeight;
    if (!w || !h) throw new Error('That picture has no size. Try another one.');
    if (w * h > MAX_PIXELS) throw new Error('That picture is too large for the browser to process (over 30 megapixels). Use a smaller one.');
    var c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    var ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    return c;
  }

  // Bytes that fit in a picture of this size, after the header.
  function capacity(w, h) {
    return Math.max(0, Math.floor((w * h * 3) / 8) - HEADER);
  }

  // Offset in the RGBA array of the k-th hidden bit (R, G, B of each pixel in turn).
  function sampleIndex(k) {
    return (((k / 3) | 0) * 4) + (k % 3);
  }

  function buildPayload(text) {
    var body = new TextEncoder().encode(text);
    var out = new Uint8Array(HEADER + body.length);
    out.set(MAGIC, 0);
    new DataView(out.buffer).setUint32(4, body.length, false);
    out.set(body, HEADER);
    return out;
  }

  function writeBits(px, bytes) {
    var bits = bytes.length * 8;
    for (var b = 0; b < bits; b++) {
      var bit = (bytes[b >> 3] >> (7 - (b & 7))) & 1;
      var i = sampleIndex(b);
      px[i] = (px[i] & 0xFE) | bit;
    }
  }

  function readBytes(px, count) {
    var out = new Uint8Array(count);
    var bits = count * 8;
    for (var b = 0; b < bits; b++) {
      out[b >> 3] |= (px[sampleIndex(b)] & 1) << (7 - (b & 7));
    }
    return out;
  }

  /* ---------- encode ---------- */
  var encodeSrc = null;   // { img, url } of the chosen picture
  var encodePick = 0;     // guards against a slow earlier pick finishing last

  function updateCapacity() {
    var el = $('encode-capacity');
    var used = new TextEncoder().encode($('encode-message').value).length;
    if (!encodeSrc) {
      el.textContent = 'Choose a picture to see how much text it can hold.';
      el.className = 'st-meta';
      return;
    }
    var w = encodeSrc.img.naturalWidth, h = encodeSrc.img.naturalHeight;
    var max = capacity(w, h);
    el.textContent = 'Room for ' + max + ' bytes in this ' + w + ' × ' + h + ' picture. Your message uses ' +
      used + ' bytes. Bangla letters take 3 bytes each.';
    el.className = 'st-meta' + (used > max ? ' over' : '');
  }

  $('encode-file').addEventListener('change', function () {
    var file = this.files && this.files[0];
    var pick = ++encodePick;
    $('encode-result').hidden = true;
    setStatus('encode-status', '');
    if (encodeSrc) { URL.revokeObjectURL(encodeSrc.url); encodeSrc = null; }
    $('encode-chosen').hidden = true;
    updateCapacity();
    if (!file) return;
    openFile(file).then(function (opened) {
      if (pick !== encodePick) { URL.revokeObjectURL(opened.url); return; }
      encodeSrc = opened;
      $('encode-preview').src = opened.url;
      $('encode-chosen').hidden = false;
      updateCapacity();
    }).catch(function (err) {
      if (pick === encodePick) setStatus('encode-status', err.message, 'err');
    });
  });

  $('encode-message').addEventListener('input', function () {
    $('encode-result').hidden = true;
    setStatus('encode-status', '');
    updateCapacity();
  });

  $('encode-btn').addEventListener('click', function () {
    $('encode-result').hidden = true;
    if (!encodeSrc) return setStatus('encode-status', 'Choose a picture first.', 'err');
    var text = $('encode-message').value;
    if (!text.trim()) return setStatus('encode-status', 'Type the message you want to hide.', 'err');
    try {
      var payload = buildPayload(text);
      var w = encodeSrc.img.naturalWidth, h = encodeSrc.img.naturalHeight;
      var max = capacity(w, h);
      var size = payload.length - HEADER;
      if (size > max) {
        return setStatus('encode-status', 'Message too long for this picture. It holds up to ' + max +
          ' bytes, and your message is ' + size + ' bytes. Choose a larger picture or shorten the message.', 'err');
      }
      var src = toCanvas(encodeSrc.img);
      var data = src.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, w, h);
      writeBits(data.data, payload);
      var out = $('encode-canvas');
      out.width = w;
      out.height = h;
      out.getContext('2d').putImageData(data, 0, 0);
      $('encode-result').hidden = false;
      setStatus('encode-status', 'Message hidden. Download the PNG to keep it.', 'ok');
    } catch (err) {
      setStatus('encode-status', err.message || 'Something went wrong while hiding the message.', 'err');
    }
  });

  $('encode-download').addEventListener('click', function () {
    $('encode-canvas').toBlob(function (blob) {
      if (!blob) return setStatus('encode-status', 'Could not create the PNG file. Try again.', 'err');
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'stenographer-encoded.png';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    }, 'image/png');
  });

  /* ---------- decode ---------- */
  var NOT_FOUND = 'No hidden message was found in this picture.';

  $('decode-file').addEventListener('change', function () {
    $('decode-result').hidden = true;
    setStatus('decode-status', '');
  });

  $('decode-btn').addEventListener('click', function () {
    var file = $('decode-file').files[0];
    $('decode-result').hidden = true;
    if (!file) return setStatus('decode-status', 'Choose the picture you want to read.', 'err');
    setStatus('decode-status', 'Reading picture…');
    openFile(file).then(function (opened) {
      try {
        var canvas = toCanvas(opened.img);
        var w = canvas.width, h = canvas.height;
        var px = canvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, w, h).data;
        if (w * h * 3 < HEADER * 8) throw new Error(NOT_FOUND);

        var head = readBytes(px, HEADER);
        for (var m = 0; m < 4; m++) {
          if (head[m] !== MAGIC[m]) throw new Error(NOT_FOUND);
        }
        var length = new DataView(head.buffer).getUint32(4, false);
        if (length > capacity(w, h)) throw new Error(NOT_FOUND);

        var all = readBytes(px, HEADER + length);
        var text;
        try {
          text = new TextDecoder('utf-8', { fatal: true }).decode(all.subarray(HEADER));
        } catch (e) {
          throw new Error('A message was found, but it is damaged. The picture was probably changed, resized or saved as JPEG after encoding.');
        }
        $('decode-message').value = text;
        $('decode-result').hidden = false;
        setStatus('decode-status', 'Message found (' + length + ' bytes).', 'ok');
      } catch (err) {
        setStatus('decode-status', err.message, 'err');
      } finally {
        URL.revokeObjectURL(opened.url);
      }
    }).catch(function (err) {
      setStatus('decode-status', err.message, 'err');
    });
  });

  $('decode-copy').addEventListener('click', function () {
    var text = $('decode-message').value;
    if (!text) return;
    if (!navigator.clipboard || !navigator.clipboard.writeText) {
      setStatus('decode-status', 'Select the text and copy it by hand.', 'err');
      return;
    }
    navigator.clipboard.writeText(text).then(function () {
      setStatus('decode-status', 'Copied to clipboard.', 'ok');
    }, function () {
      setStatus('decode-status', 'Select the text and copy it by hand.', 'err');
    });
  });

  showTab('encode');
  updateCapacity();
})();
