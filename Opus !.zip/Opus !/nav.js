/* CPS navigation for the standalone tool pages (pages that do not load script.js):
   3-dot drawer menu, Ctrl+K page search, navbar scroll state and the flame layers on the 3-dot.
   Same behaviour as script.js on the main pages. */
(function () {
  'use strict';

  var PAGES = [{"t": "Home", "d": "Cyber Prime Squad · Ethical hacking team", "u": "index.html", "i": "fa-home"}, {"t": "CPS AI", "d": "Powerful AI chat · Image gen", "u": "cps-ai.html", "i": "fa-robot"}, {"t": "Skills", "d": "Languages · Linux · Security tools", "u": "skills.html", "i": "fa-code"}, {"t": "OS Guide", "d": "Kali · Arch · Debian · Termux install", "u": "os-install.html", "i": "fa-download"}, {"t": "Resources", "d": "Guides · links · notes", "u": "resources.html", "i": "fa-book"}, {"t": "Contact", "d": "Email · WhatsApp · Telegram · Discord", "u": "contact.html", "i": "fa-envelope"}, {"t": "Tools", "d": "Nmap · Burp · Metasploit · install guides", "u": "tools.html", "i": "fa-toolbox"}, {"t": "Recon", "d": "Passive · Active · OSINT methodology", "u": "recon.html", "i": "fa-satellite"}, {"t": "Toolkit", "d": "Password · AES · Hash · QR · Base64 tools", "u": "toolkit.html", "i": "fa-key"}, {"t": "OSINT Lab", "d": "URL · IP · Email · MAC · Phone OSINT scans", "u": "osint-lab.html", "i": "fa-satellite-dish"}, {"t": "Code Editor", "d": "In-browser code tools · HTML/CSS/JS", "u": "code-editor.html", "i": "fa-code"}, {"t": "Interests", "d": "Topics we care about", "u": "interests.html", "i": "fa-heart"}, {"t": "SMM", "d": "Social media panels", "u": "smm.html", "i": "fa-bullhorn"}, {"t": "FB DP", "d": "Facebook profile picture download", "u": "facebook-dp-downloader.html", "i": "fa-facebook"}, {"t": "Portrait", "d": "Random portrait generator", "u": "random-portrait.html", "i": "fa-user-circle"}, {"t": "Temp Mail", "d": "Disposable email for testing", "u": "temp-mail.html", "i": "fa-envelope-open-text"}, {"t": "Weather", "d": "World weather explorer", "u": "sayan-weather.html", "i": "fa-cloud-sun"}, {"t": "Spamming", "d": "Analysis · awareness", "u": "spamming.html", "i": "fa-user-secret"}, {"t": "SQLi", "d": "SQL injection guide", "u": "sqli.html", "i": "fa-database"}, {"t": "XSS", "d": "Cross-site scripting guide", "u": "xss.html", "i": "fa-code"}, {"t": "CPS Image", "d": "Upload · Host · Share", "u": "tcf-image.html", "i": "fa-images"}, {"t": "BG Remover", "d": "Remove image backgrounds", "u": "bg-remover.html", "i": "fa-eraser"}, {"t": "YT Thumbnail", "d": "Download HD YouTube thumbnails", "u": "yt-thumbnail.html", "i": "fa-youtube"}, {"t": "Video", "d": "HD video & MP3 downloader", "u": "video.html", "i": "fa-video"}, {"t": "TikTok", "d": "Video & audio downloader", "u": "tiktok.html", "i": "fa-music"}, {"t": "Repeater", "d": "Text repeater tool", "u": "repeater.html", "i": "fa-repeat"}, {"t": "Explorer", "d": "HD · 4K · 8K images", "u": "explorer.html", "i": "fa-compass"}, {"t": "Additional", "d": "Report message templates", "u": "additional.html", "i": "fa-file-alt"}, {"t": "FF", "d": "Free Fire market value", "u": "tcf-ff-market-value.html", "i": "fa-gem"}, {"t": "CPS System", "d": "System interface · Matrix", "u": "jh-system.html", "i": "fa-terminal"}, {"t": "Stenographer", "d": "Hide secret text in pictures", "u": "stenographer.html", "i": "fa-eye-slash"}];

  /* navbar state on scroll */
  var navbar = document.querySelector('.navbar');
  if (navbar) {
    var onScroll = function () { navbar.classList.toggle('scrolled', window.scrollY > 40); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* 3-dot toggle + drawer */
  var toggle = document.getElementById('nav-toggle');
  var drawer = document.getElementById('nav-drawer');
  var overlay = document.getElementById('nav-overlay');

  if (toggle && !toggle.querySelector('.flame-layer')) {
    ['flame-layer f1', 'flame-layer f2', 'flame-layer f3'].forEach(function (cls) {
      var layer = document.createElement('span');
      layer.className = cls;
      layer.setAttribute('aria-hidden', 'true');
      toggle.appendChild(layer);
    });
    var sparks = document.createElement('span');
    sparks.className = 'flame-sparks';
    sparks.setAttribute('aria-hidden', 'true');
    for (var i = 0; i < 8; i++) sparks.appendChild(document.createElement('i'));
    toggle.appendChild(sparks);
  }

  function openMenu() {
    if (toggle) toggle.classList.add('open');
    if (drawer) {
      drawer.style.display = 'flex';
      requestAnimationFrame(function () { drawer.classList.add('open'); });
    }
    if (overlay) overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    if (toggle) toggle.classList.remove('open');
    if (drawer) {
      drawer.classList.remove('open');
      setTimeout(function () {
        if (drawer && !drawer.classList.contains('open')) drawer.style.display = 'none';
      }, 350);
    }
    if (overlay) overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (toggle) toggle.addEventListener('click', function () {
    if (drawer && drawer.classList.contains('open')) closeMenu();
    else openMenu();
  });
  if (overlay) overlay.addEventListener('click', closeMenu);

  /* Ctrl+K page search */
  var searchBtn = document.createElement('button');
  searchBtn.type = 'button';
  searchBtn.className = 'nav-search-btn';
  searchBtn.id = 'nav-search-btn';
  searchBtn.setAttribute('aria-label', 'Search pages');
  searchBtn.innerHTML = '<i class="fas fa-search"></i>';
  if (toggle && toggle.parentNode) toggle.parentNode.insertBefore(searchBtn, toggle);
  else {
    var container = document.querySelector('.nav-actions') || document.querySelector('.nav-container');
    if (container) container.appendChild(searchBtn);
  }

  var searchEl = document.createElement('div');
  searchEl.className = 'search-overlay';
  searchEl.id = 'search-overlay';
  searchEl.innerHTML =
    '<div class="search-box"><input type="search" id="site-search-input" placeholder="Search pages… (Ctrl+K)" autocomplete="off" />' +
    '<div class="search-results" id="site-search-results"></div></div>';
  document.body.appendChild(searchEl);

  var input = searchEl.querySelector('#site-search-input');
  var results = searchEl.querySelector('#site-search-results');

  function render(q) {
    q = (q || '').toLowerCase().trim();
    var list = PAGES.filter(function (p) {
      return !q || p.t.toLowerCase().indexOf(q) >= 0 || p.d.toLowerCase().indexOf(q) >= 0;
    });
    results.innerHTML = list.map(function (p) {
      return '<a class="search-result" href="' + p.u + '"><i class="fas ' + p.i + '"></i><div><div class="sr-title">' +
        p.t + '</div><div class="sr-desc">' + p.d + '</div></div></a>';
    }).join('') || '<div style="padding:12px;color:rgba(255,255,255,.4);font-size:13px;">No matches</div>';
  }
  function openSearch() {
    searchEl.classList.add('open');
    setTimeout(function () { input.focus(); input.select(); }, 50);
    render('');
  }
  function closeSearch() { searchEl.classList.remove('open'); }

  searchBtn.addEventListener('click', openSearch);
  searchEl.addEventListener('click', function (e) { if (e.target === searchEl) closeSearch(); });
  input.addEventListener('input', function () { render(input.value); });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openSearch(); }
    if (e.key === 'Escape') { closeMenu(); closeSearch(); }
  });
})();
