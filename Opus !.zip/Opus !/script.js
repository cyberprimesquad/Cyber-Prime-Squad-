(function () {
  'use strict';

  /* ===== SAFETY ===== */
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && 'IJCijc'.indexOf(e.key) !== -1) ||
        (e.ctrlKey && (e.key === 'u' || e.key === 'U' || e.key === 's' || e.key === 'S'))) {
      e.preventDefault();
    }
  });

  /* ===== CURSOR ===== */
  var cursor = document.querySelector('.cursor');
  var follower = document.querySelector('.cursor-follower');
  var mouseX = 0, mouseY = 0, fx = 0, fy = 0;
  if (cursor && follower && window.matchMedia('(pointer:fine)').matches) {
    document.addEventListener('mousemove', function (e) {
      mouseX = e.clientX; mouseY = e.clientY;
      cursor.style.left = mouseX + 'px';
      cursor.style.top = mouseY + 'px';
    });
    (function loop() {
      fx += (mouseX - fx) * 0.15;
      fy += (mouseY - fy) * 0.15;
      follower.style.left = fx + 'px';
      follower.style.top = fy + 'px';
      requestAnimationFrame(loop);
    })();
    document.querySelectorAll('a, button, .portfolio-item, .lang-card, .btn, .cse-card, .contact-card, .meta-card, .distro-card, .tool-card, .explore-card, .recon-card, .menu-item, .os-card').forEach(function (el) {
      el.addEventListener('mouseenter', function () { document.body.classList.add('hovering'); });
      el.addEventListener('mouseleave', function () { document.body.classList.remove('hovering'); });
    });
  }

  /* ===== 3D TILT ===== */
  function initTilt() {
    if (!window.matchMedia('(pointer:fine)').matches) return;
    document.querySelectorAll('.cse-card, .lang-card, .explore-card, .portfolio-item, .recon-card, .meta-card, .os-card').forEach(function (card) {
      card.addEventListener('mousemove', function (e) {
        var r = card.getBoundingClientRect();
        var rotX = ((e.clientY - r.top - r.height / 2) / (r.height / 2)) * -5;
        var rotY = ((e.clientX - r.left - r.width / 2) / (r.width / 2)) * 5;
        card.style.transform = 'perspective(900px) rotateX(' + rotX + 'deg) rotateY(' + rotY + 'deg) translateY(-3px)';
      });
      card.addEventListener('mouseleave', function () { card.style.transform = ''; });
    });
  }
  window.addEventListener('load', initTilt);

  /* ===== NAVBAR SCROLL ===== */
  var navbar = document.querySelector('.navbar');
  window.addEventListener('scroll', function () {
    if (navbar) navbar.classList.toggle('scrolled', window.scrollY > 40);
  }, { passive: true });

  
  /* ===== PURPLE FIRE layers on 3-dot ===== */
  (function initFireToggle() {
    var toggle = document.getElementById('nav-toggle');
    if (!toggle || toggle.querySelector('.flame-layer')) return;
    var f1 = document.createElement('span'); f1.className = 'flame-layer f1'; f1.setAttribute('aria-hidden','true');
    var f2 = document.createElement('span'); f2.className = 'flame-layer f2'; f2.setAttribute('aria-hidden','true');
    var f3 = document.createElement('span'); f3.className = 'flame-layer f3'; f3.setAttribute('aria-hidden','true');
    var sparks = document.createElement('span'); sparks.className = 'flame-sparks'; sparks.setAttribute('aria-hidden','true');
    for (var i = 0; i < 8; i++) sparks.appendChild(document.createElement('i'));
    toggle.appendChild(f1); toggle.appendChild(f2); toggle.appendChild(f3); toggle.appendChild(sparks);
  })();

  /* ===== DRAWER MENU ===== */
  var toggle = document.getElementById('nav-toggle');
  var drawer = document.getElementById('nav-drawer');
  var overlay = document.getElementById('nav-overlay');

  function openMenu() {
    if (toggle) toggle.classList.add('open');
    if (drawer) {
      drawer.style.display = 'flex';
      requestAnimationFrame(function () { drawer.classList.add('open'); });
    }
    if (overlay) overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    if (toggle) toggle.classList.remove('open');
    if (drawer) {
      drawer.classList.remove('open');
      setTimeout(function () {
        if (drawer && !drawer.classList.contains('open')) drawer.style.display = 'none';
      }, 350);
    }
    if (overlay) overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
  if (toggle) toggle.addEventListener('click', function () {
    if (drawer && drawer.classList.contains('open')) closeMenu();
    else openMenu();
  });
  if (overlay) overlay.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { closeMenu(); closeDetailModal(); }
  });

  /* ===== TYPING ===== */
  var typedEl = document.getElementById('typed-text');
  if (typedEl) {
    var phrases = [
      'ethical_hacking',
      'penetration_testing',
      'digital_forensics',
      'network_defense',
      'vulnerability_research',
      'security_awareness',
      'we_are_cps'
    ];
    var pi = 0, ci = 0, del = false;
    function type() {
      var cur = phrases[pi];
      if (!del) {
        typedEl.textContent = cur.slice(0, ci + 1);
        ci++;
        if (ci === cur.length) { del = true; setTimeout(type, 1600); return; }
      } else {
        typedEl.textContent = cur.slice(0, ci - 1);
        ci--;
        if (ci === 0) { del = false; pi = (pi + 1) % phrases.length; }
      }
      setTimeout(type, del ? 36 : 68);
    }
    setTimeout(type, 500);
  }

  /* ===== PARTICLES ===== */
  var canvas = document.getElementById('particle-canvas');
  if (canvas) {
    var ctx = canvas.getContext('2d');
    var particles = [];
    var W, H;
    function resize() {
      W = canvas.width = window.innerWidth;
      H = canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);
    var n = Math.min(85, Math.floor((window.innerWidth * window.innerHeight) / 14000));
    for (var i = 0; i < n; i++) {
      particles.push({
        x: Math.random() * W, y: Math.random() * H,
        r: Math.random() * 1.7 + 0.3,
        vx: (Math.random() - 0.5) * 0.38,
        vy: (Math.random() - 0.5) * 0.38,
        a: Math.random() * 0.5 + 0.12
      });
    }
    function draw() {
      ctx.clearRect(0, 0, W, H);
      for (var i = 0; i < particles.length; i++) {
        var p = particles[i];
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
        if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,229,255,' + p.a + ')';
        ctx.fill();
        for (var j = i + 1; j < particles.length; j++) {
          var q = particles[j];
          var dx = p.x - q.x, dy = p.y - q.y;
          var d = Math.sqrt(dx * dx + dy * dy);
          if (d < 125) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = 'rgba(0,229,255,' + (0.09 * (1 - d / 125)) + ')';
            ctx.lineWidth = 0.65;
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(draw);
    }
    draw();
  }

  /* ===== SKILL BARS ===== */
  var skillsDone = false;
  function animateSkills() {
    if (skillsDone) return;
    var rows = document.querySelectorAll('.skill-row[data-width]');
    if (!rows.length) return;
    if (rows[0].getBoundingClientRect().top < window.innerHeight * 0.85) {
      rows.forEach(function (row) {
        var w = row.getAttribute('data-width') || '80';
        var fill = row.querySelector('.fill');
        if (fill) fill.style.width = w + '%';
      });
      skillsDone = true;
    }
  }
  window.addEventListener('scroll', animateSkills, { passive: true });
  window.addEventListener('load', animateSkills);

  /* ===== DATA: DISTROS ===== */
  var distroData = {
    linux: {
      title: 'Linux', level: 'Daily driver',
      icon: '<i class="devicon-linux-plain colored" style="font-size:28px;"></i>',
      base: 'Kernel', pm: 'Varies', use: 'Everything',
      desc: 'The kernel and ecosystem everything else is built on. Daily work spans Arch for development, Debian for servers, and security spins for CTF/research.',
      install: 'Foundation of every distro below.\nLearn kernel, systemd, networking, cgroups once — transfers everywhere.\n\nTermux: pkg install proot-distro\nThen install any supported distro with proot-distro.',
      tags: ['Kernel', 'systemd', 'cgroups', 'Networking', 'Shell']
    },
    arch: {
      title: 'Arch Linux', level: 'Advanced',
      icon: '<i class="devicon-archlinux-plain colored" style="font-size:28px;"></i>',
      base: 'Independent', pm: 'pacman / AUR', use: 'Daily driver, dev',
      desc: 'Main workstation. Minimal by default — everything installed is intentional. Best for understanding the stack end-to-end.',
      install: 'ISO: https://archlinux.org/download/\n\nVirtualBox / VMware:\n1. New VM → Linux → Other Linux (64-bit)\n2. 2+ GB RAM, 20+ GB disk, EFI optional\n3. Attach ISO → boot → follow ArchWiki Installation Guide\n4. pacstrap /mnt base linux linux-firmware\n\nBare metal: same, write ISO to USB with dd or Rufus.\n\nTermux (proot):\npkg install proot-distro\nproot-distro install archlinux\nproot-distro login archlinux',
      tags: ['Rolling', 'AUR', 'Minimal', 'Wiki-driven', 'proot']
    },
    debian: {
      title: 'Debian', level: 'Advanced',
      icon: '<i class="devicon-debian-plain colored" style="font-size:28px;"></i>',
      base: 'Independent', pm: 'apt / dpkg', use: 'Servers, VPS',
      desc: 'Go-to for production: VPS, backends, home servers. Long cycles, conservative packages, fewer surprises.',
      install: 'ISO: https://www.debian.org/CD/http-ftp/ (netinst recommended)\n\nVirtualBox / VMware:\n1. New VM → Debian (64-bit)\n2. Guided partitioning → enable SSH server\n3. Minimal install then apt install what you need\n\nBare metal: netinst ISO to USB.\n\nTermux (proot):\npkg install proot-distro\nproot-distro install debian\nproot-distro login debian',
      tags: ['Stability', 'LTS', 'Servers', 'apt', 'proot']
    },
    fedora: {
      title: 'Fedora', level: 'Working',
      icon: '<i class="devicon-fedora-plain colored" style="font-size:28px;"></i>',
      base: 'Upstream RHEL', pm: 'dnf', use: 'Testing, desktop',
      desc: 'Tracks upstream closely — useful early signal for what lands in enterprise Linux later.',
      install: 'ISO: https://getfedora.org/ (Workstation or Server)\n\nVirtualBox / VMware:\n1. New VM → Fedora (64-bit)\n2. Automatic partitioning is fine for lab\n3. After install: dnf install @development-tools\n\nBare metal: write ISO, boot, installer is graphical.\n\nTermux (proot):\npkg install proot-distro\nproot-distro install fedora\nproot-distro login fedora',
      tags: ['SELinux', 'GNOME', 'Newer kernels', 'dnf', 'proot']
    },
    ubuntu: {
      title: 'Ubuntu', level: 'Working',
      icon: '<i class="devicon-ubuntu-plain colored" style="font-size:28px;"></i>',
      base: 'Debian', pm: 'apt / snap', use: 'Cloud, onboarding',
      desc: 'Default on many cloud images and CI runners. Easy recommendation for newcomers and cloud VMs.',
      install: 'ISO: https://ubuntu.com/download (Desktop or Server LTS)\n\nVirtualBox / VMware:\n1. New VM → Ubuntu (64-bit)\n2. Easy installer, enable OpenSSH on Server\n3. cloud-init friendly on most VPS providers\n\nBare metal: Rufus / Etcher to USB.\n\nTermux (proot):\npkg install proot-distro\nproot-distro install ubuntu\nproot-distro login ubuntu',
      tags: ['Cloud', 'LTS', 'CI/CD', 'snap', 'proot']
    },
    kali: {
      title: 'Kali Linux', level: 'Security / CTF',
      icon: '<img src="https://cdn.simpleicons.org/kalilinux/2777FF" width="28" height="28" alt="Kali">',
      base: 'Debian', pm: 'apt', use: 'Pentesting, CTF',
      desc: 'Standard CTF/pentest environment. Recon, exploitation, and web tooling preinstalled. Prefer VM for safety.',
      install: 'ISO / VM: https://www.kali.org/get-kali/\nOfficial VirtualBox & VMware images available.\n\nVirtualBox:\n1. Import official .ova or create new VM + ISO\n2. 2+ GB RAM, bridged or NAT network\n3. Prefer non-root daily user\n\nBare metal: possible but not recommended for daily driver.\n\nTermux: Kali has community support via proot or NetHunter (advanced).\nSimple path: proot Debian + selective tools.',
      tags: ['Pentest', 'CTF', 'Metasploit', 'Burp', 'VM preferred']
    },
    parrot: {
      title: 'Parrot OS', level: 'Security',
      icon: '<img src="https://cdn.simpleicons.org/parrotsecurity/00A86B" width="28" height="28" alt="Parrot">',
      base: 'Debian', pm: 'apt', use: 'Security, privacy',
      desc: 'Lighter Kali alternative with sandboxing and privacy tooling, usable as daily desktop.',
      install: 'ISO: https://www.parrotsec.org/download/\nSecurity or Home edition.\n\nVirtualBox / VMware: create Debian-like VM, attach ISO, install.\n2+ GB RAM recommended.\n\nBare metal: USB install supported.\n\nTermux: use Debian proot then add Parrot repos, or community images.',
      tags: ['AnonSurf', 'Forensics', 'Sandbox', 'Privacy']
    },
    blackarch: {
      title: 'BlackArch', level: 'Security',
      icon: '<i class="fas fa-dragon" style="color:#7c4dff;font-size:26px;"></i>',
      base: 'Arch', pm: 'pacman overlay', use: 'Deep CTF tooling',
      desc: 'Huge security tool catalog as Arch overlay. Reach for obscure tools Kali does not ship.',
      install: 'ISO / strap: https://blackarch.org/\n\nRecommended path:\n1. Install Arch first (VM or bare)\n2. curl -O https://blackarch.org/strap.sh\n3. chmod +x strap.sh && sudo ./strap.sh\n4. pacman -Syyu && pacman -S blackarch\n\nVirtualBox: Arch base VM + strap is cleanest.\n\nTermux: proot Arch then run strap inside the proot.',
      tags: ['2800+ tools', 'Arch', 'CTF', 'Overlay']
    },
    manjaro: {
      title: 'Manjaro', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/manjaro/35BF5C" width="28" height="28" alt="Manjaro">',
      base: 'Arch', pm: 'pacman / AUR', use: 'Desktop, testing',
      desc: 'Arch power with curated snapshots and friendlier installer.',
      install: 'ISO: https://manjaro.org/download/\n\nVirtualBox / VMware: New VM → Linux → Manjaro, attach ISO, graphical installer is easy.\n\nBare metal: same ISO to USB.\n\nTermux: proot Arch is closer; Manjaro-specific proot less common.',
      tags: ['Arch-based', 'Curated', 'Desktop']
    },
    popos: {
      title: 'Pop!_OS', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/popos/48B9C7" width="28" height="28" alt="Pop!_OS">',
      base: 'Ubuntu', pm: 'apt', use: 'Dev workstation',
      desc: 'System76 spin with tiling-friendly desktop and solid NVIDIA/AMD driver support.',
      install: 'ISO: https://pop.system76.com/\n\nVirtualBox / VMware: treat as Ubuntu, attach ISO, installer is polished.\n\nBare metal: excellent for dual-GPU laptops.\n\nTermux: use Ubuntu proot (same base).',
      tags: ['Tiling', 'Drivers', 'Dev']
    },
    rocky: {
      title: 'Rocky Linux', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/rockylinux/10B981" width="28" height="28" alt="Rocky">',
      base: 'RHEL clone', pm: 'dnf', use: 'Enterprise servers',
      desc: 'CentOS replacement for RHEL-compatible production with long support windows.',
      install: 'ISO: https://rockylinux.org/download\nMinimal or DVD.\n\nVirtualBox / VMware: New VM → Red Hat (64-bit) or Other Linux, attach ISO.\n\nBare metal / VPS: common on enterprise and cloud images.\n\nTermux: proot Fedora is closest practical option.',
      tags: ['RHEL', 'LTS', 'SELinux', 'Enterprise']
    },
    qubes: {
      title: 'Qubes OS', level: 'Security',
      icon: '<img src="https://cdn.simpleicons.org/qubesos/3874D8" width="28" height="28" alt="Qubes">',
      base: 'Xen + Fedora', pm: 'dnf per-qube', use: 'Isolation, research',
      desc: 'Security by compartmentalization — apps in disposable Xen VMs. Requires VT-x/AMD-V + IOMMU.',
      install: 'ISO: https://www.qubes-os.org/downloads/\n\nHardware: enable virtualization + IOMMU in BIOS.\nBare metal only (nested virt is limited).\n\nVirtualBox: not recommended (needs hardware virt features).\n\nTermux: not applicable (Xen-based).',
      tags: ['Xen', 'Disposable VMs', 'Isolation', 'Hardware virt']
    },
    tails: {
      title: 'Tails', level: 'Privacy',
      icon: '<i class="fas fa-user-secret" style="color:#8b5cf6;font-size:26px;"></i>',
      base: 'Debian', pm: 'apt', use: 'Anonymous, amnesic',
      desc: 'Amnesic live OS. Everything via Tor. Leaves no trace on host after shutdown.',
      install: 'ISO: https://tails.net/install/\nAlways verify signature.\n\nUSB only (recommended): Etcher, dd, or Tails installer.\n\nVirtualBox: possible for testing (limited persistence features).\n\nTermux: not applicable (live amnesic design).',
      tags: ['Tor', 'Amnesic', 'USB', 'Privacy']
    },
    mint: {
      title: 'Linux Mint', level: 'Desktop',
      icon: '<img src="https://cdn.simpleicons.org/linuxmint/86BE43" width="28" height="28" alt="Mint">',
      base: 'Ubuntu / Debian', pm: 'apt', use: 'Friendly desktop',
      desc: 'Polished Cinnamon/MATE/Xfce desktops on Ubuntu LTS. Excellent for users moving from Windows — multimedia codecs, timeshift, and a calm UI out of the box.',
      install: 'ISO: https://linuxmint.com/download.php\n\nVirtualBox: New VM → Ubuntu (64-bit), 2+ GB RAM, attach ISO, guided install.\nBare metal: USB with Etcher/Rufus, dual-boot friendly.\n\nTermux: proot Ubuntu is the closest practical base.',
      tags: ['Cinnamon', 'LTS', 'Beginner-friendly', 'Timeshift']
    },
    opensuse: {
      title: 'openSUSE', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/opensuse/73BA25" width="28" height="28" alt="openSUSE">',
      base: 'Independent (RPM)', pm: 'zypper / YaST', use: 'Desktop & servers',
      desc: 'Leap (stable) and Tumbleweed (rolling). Strong YaST tooling, Btrfs snapshots, and solid enterprise DNA from SUSE.',
      install: 'ISO: https://get.opensuse.org/\n\nVirtualBox: Leap or Tumbleweed ISO, 2+ GB RAM. YaST guides partitioning.\nAfter install: sudo zypper refresh && sudo zypper update\n\nTermux: no first-class proot; use Fedora/openSUSE containers elsewhere.',
      tags: ['YaST', 'zypper', 'Btrfs', 'Leap / Tumbleweed']
    },
    gentoo: {
      title: 'Gentoo Linux', level: 'Advanced',
      icon: '<img src="https://cdn.simpleicons.org/gentoo/54487A" width="28" height="28" alt="Gentoo">',
      base: 'Independent', pm: 'Portage (emerge)', use: 'Source-based, tuned systems',
      desc: 'Compile what you need with USE flags. Maximum control and learning — not a quick desktop install. Handbook is the source of truth.',
      install: 'Handbook: https://wiki.gentoo.org/wiki/Handbook:Main_Page\n\nVirtualBox: possible but slow (compiles). Prefer bare metal or powerful host.\nStage3 tarball → chroot → emerge world.\n\nTermux: not practical for full Gentoo builds.',
      tags: ['Portage', 'USE flags', 'Source-based', 'Handbook']
    },
    nixos: {
      title: 'NixOS', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/nixos/5277C3" width="28" height="28" alt="NixOS">',
      base: 'Independent', pm: 'Nix', use: 'Declarative, reproducible',
      desc: 'Entire system declared in configuration.nix. Rollbacks, pure builds, and reproducible environments — steep curve, powerful payoff.',
      install: 'ISO: https://nixos.org/download/\n\nVirtualBox: Graphical or minimal ISO, follow installer, edit configuration.nix.\nDocs: https://nixos.org/manual/nixos/stable/\n\nTermux: Nix can be installed user-level; full NixOS needs real VM/bare metal.',
      tags: ['Declarative', 'configuration.nix', 'Rollbacks', 'Reproducible']
    },
    alpine: {
      title: 'Alpine Linux', level: 'Containers',
      icon: '<img src="https://cdn.simpleicons.org/alpinelinux/0D597F" width="28" height="28" alt="Alpine">',
      base: 'Independent (musl)', pm: 'apk', use: 'Containers, minimal hosts',
      desc: 'Tiny musl-based distro. Default base for countless Docker images. Fast, secure, and small attack surface.',
      install: 'ISO: https://alpinelinux.org/downloads/\n\nVirtualBox: Standard or Extended ISO, setup-alpine script is excellent.\nDocker: FROM alpine:latest\n\nTermux: apk not native; use proot or containers.',
      tags: ['musl', 'apk', 'Docker base', 'Minimal']
    },
    endeavouros: {
      title: 'EndeavourOS', level: 'Arch-based',
      icon: '<img src="https://cdn.simpleicons.org/endeavouros/7F3FBF" width="28" height="28" alt="EndeavourOS">',
      base: 'Arch', pm: 'pacman / AUR', use: 'Friendly Arch desktop',
      desc: 'Arch with a guided installer and welcoming community. Close to vanilla Arch after install — great on-ramp without Manjaro’s curated lag.',
      install: 'ISO: https://endeavouros.com/\n\nVirtualBox / bare metal: offline or online installer, pick DE, reboot into Arch-like system.\n\nTermux: proot Arch is the parallel path.',
      tags: ['Arch', 'Calamares', 'AUR', 'Community']
    },
    garuda: {
      title: 'Garuda Linux', level: 'Gaming / Arch',
      icon: '<i class="fas fa-feather-alt" style="color:#00A0E3;font-size:26px;"></i>',
      base: 'Arch', pm: 'pacman / Chaotic-AUR', use: 'Gaming, performance desktop',
      desc: 'Arch-based with opinionated performance defaults, Btrfs snapshots, and gaming-focused spins. Heavy out of the box — great for show, tune for daily use.',
      install: 'ISO: https://garudalinux.org/downloads\n\nVirtualBox: 4+ GB RAM recommended. Graphical installer.\nBare metal: Btrfs layout is the default path.\n\nTermux: use proot Arch.',
      tags: ['Arch', 'Btrfs', 'Gaming', 'Chaotic-AUR']
    },
    elementary: {
      title: 'elementary OS', level: 'Desktop',
      icon: '<img src="https://cdn.simpleicons.org/elementary/64BAFF" width="28" height="28" alt="elementary">',
      base: 'Ubuntu LTS', pm: 'apt / Flatpak', use: 'Opinionated desktop',
      desc: 'macOS-inspired Pantheon desktop, curated app center, and strong design focus. Pay-what-you-want downloads support the project.',
      install: 'ISO: https://elementary.io/\n\nVirtualBox: treat as Ubuntu, 2+ GB RAM.\nBare metal: clean installer, great for laptops.\n\nTermux: Ubuntu proot.',
      tags: ['Pantheon', 'Design', 'Ubuntu LTS', 'Flatpak']
    },
    void: {
      title: 'Void Linux', level: 'Independent',
      icon: '<img src="https://cdn.simpleicons.org/voidlinux/478061" width="28" height="28" alt="Void">',
      base: 'Independent', pm: 'xbps', use: 'runit, rolling, minimal',
      desc: 'Independent rolling release with runit (not systemd), xbps package manager, and both glibc and musl variants. Clean and fast.',
      install: 'ISO / rootfs: https://voidlinux.org/download/\n\nVirtualBox: live ISO → void-installer or manual.\nDocs: https://docs.voidlinux.org/\n\nTermux: community rootfs possible; not official proot-distro.',
      tags: ['runit', 'xbps', 'musl/glibc', 'Rolling']
    },
    alma: {
      title: 'AlmaLinux', level: 'Enterprise',
      icon: '<img src="https://cdn.simpleicons.org/almalinux/0F70B9" width="28" height="28" alt="AlmaLinux">',
      base: 'RHEL clone', pm: 'dnf', use: 'Production servers',
      desc: 'Community-owned RHEL-compatible OS. Drop-in path for CentOS refugees who need long support and certification-friendly userland.',
      install: 'ISO: https://almalinux.org/get-alma/\n\nVirtualBox: RHEL-like VM, minimal or DVD ISO.\nCloud images widely available.\n\nTermux: Fedora proot is closest.',
      tags: ['RHEL', 'dnf', 'LTS', 'Enterprise']
    },
    mx: {
      title: 'MX Linux', level: 'Desktop',
      icon: '<i class="fas fa-cube" style="color:#1a73e8;font-size:26px;"></i>',
      base: 'Debian', pm: 'apt', use: 'Stable desktop, tools',
      desc: 'Debian Stable with MX Tools, advanced installer options, and a focus on midweight desktops (Xfce default). Frequently tops DistroWatch interest lists.',
      install: 'ISO: https://mxlinux.org/download-links/\n\nVirtualBox: Debian-like VM, 2 GB RAM.\nBare metal: advanced installer supports snapshot persistence quirks.\n\nTermux: Debian proot.',
      tags: ['Debian', 'Xfce', 'MX Tools', 'Stable']
    },
    zorin: {
      title: 'Zorin OS', level: 'Desktop',
      icon: '<i class="fas fa-desktop" style="color:#15A6F0;font-size:26px;"></i>',
      base: 'Ubuntu LTS', pm: 'apt', use: 'Windows/macOS migrants',
      desc: 'Layout modes that mimic Windows or macOS, educational and Pro editions. Polished onboarding for people switching platforms.',
      install: 'ISO: https://zorin.com/os/download/\n\nVirtualBox: Ubuntu-like, 2+ GB RAM.\nBare metal: straightforward installer.\n\nTermux: Ubuntu proot.',
      tags: ['Ubuntu LTS', 'Layouts', 'Migration', 'Education']
    },
    solus: {
      title: 'Solus', level: 'Desktop',
      icon: '<img src="https://cdn.simpleicons.org/solus/48919B" width="28" height="28" alt="Solus">',
      base: 'Independent', pm: 'eopkg', use: 'Curated desktop',
      desc: 'Independent desktop OS with Budgie (origin), Plasma, GNOME, and MATE. Curated repos and a focus on being a daily driver, not a toolkit.',
      install: 'ISO: https://getsol.us/\n\nVirtualBox: 2+ GB RAM, graphical installer.\nBare metal: well-supported on common hardware.\n\nTermux: not first-class.',
      tags: ['Budgie', 'eopkg', 'Independent', 'Desktop']
    },
    artix: {
      title: 'Artix Linux', level: 'systemd-free',
      icon: '<i class="fas fa-circle-notch" style="color:#10A0C0;font-size:26px;"></i>',
      base: 'Arch (OpenRC/runit/s6)', pm: 'pacman', use: 'Arch without systemd',
      desc: 'Arch userland with OpenRC, runit, s6, or dinit instead of systemd. For those who want Arch packages and a different init philosophy.',
      install: 'ISO: https://artixlinux.org/download.php\n\nVirtualBox / bare metal: pick init variant ISO, follow install wiki.\nBase is very close to Arch after install.\n\nTermux: proot Arch + manual init is not equivalent.',
      tags: ['OpenRC', 'runit', 'Arch', 'No systemd']
    },
    slackware: {
      title: 'Slackware', level: 'Classic',
      icon: '<img src="https://cdn.simpleicons.org/slackware/000000" width="28" height="28" alt="Slackware" style="filter:invert(1)">',
      base: 'Independent', pm: 'pkgtool / slackpkg', use: 'Unix-like simplicity',
      desc: 'Oldest surviving Linux distro still actively maintained. Conservative, script-driven, KISS philosophy. Learning Slackware teaches a lot about Unix.',
      install: 'ISO: https://www.slackware.com/getslack/\n\nVirtualBox: classic text installer, plan partitions.\nDocs: Slackware book and FAQ on slackware.com.\n\nTermux: not practical.',
      tags: ['KISS', 'pkgtool', 'Classic', 'Unix-like']
    },
    cachyos: {
      title: 'CachyOS', level: 'Performance',
      icon: '<i class="fas fa-bolt" style="color:#00BFFF;font-size:26px;"></i>',
      base: 'Arch', pm: 'pacman', use: 'Optimized kernels & desktop',
      desc: 'Arch-based with performance-oriented kernels, schedulers, and package builds. Targets users who want speed tweaks without building everything by hand.',
      install: 'ISO: https://cachyos.org/\n\nVirtualBox / bare metal: graphical installer, 2+ GB RAM.\nFollow project docs for kernel flavors.\n\nTermux: proot Arch.',
      tags: ['Arch', 'Kernel', 'Performance', 'Desktop']
    },
    nobara: {
      title: 'Nobara Linux', level: 'Gaming',
      icon: '<i class="fas fa-gamepad" style="color:#E84A4A;font-size:26px;"></i>',
      base: 'Fedora', pm: 'dnf', use: 'Gaming & creative work',
      desc: 'Fedora-based spin by GloriousEggroll with gaming fixes, codecs, and opinionated defaults. Popular among Proton/Steam users who want less manual setup.',
      install: 'ISO: https://nobaraproject.org/\n\nVirtualBox: 4 GB RAM recommended for gaming stack testing.\nBare metal: follow official download + checksum.\n\nTermux: Fedora proot.',
      tags: ['Fedora', 'Gaming', 'Proton', 'Codecs']
    },
    deepin: {
      title: 'Deepin', level: 'Desktop',
      icon: '<img src="https://cdn.simpleicons.org/deepin/00A2E8" width="28" height="28" alt="Deepin">',
      base: 'Debian', pm: 'apt', use: 'DDE desktop',
      desc: 'Debian-based with the Deepin Desktop Environment — polished animations and app suite. Strong visual identity; review privacy/update practices for your threat model.',
      install: 'ISO: https://www.deepin.org/en/download/\n\nVirtualBox: 2+ GB RAM, enable 3D if available for DDE.\nBare metal: graphical installer.\n\nTermux: Debian proot.',
      tags: ['DDE', 'Debian', 'Desktop', 'Polished UI']
    },
    freebsd: {
      title: 'FreeBSD', level: 'Unix-like',
      icon: '<img src="https://cdn.simpleicons.org/freebsd/AB2B28" width="28" height="28" alt="FreeBSD">',
      base: 'BSD', pm: 'pkg / ports', use: 'Servers, networking, ZFS',
      desc: 'Not Linux — a complete Unix-like OS with a different kernel, userland, and license. Excellent networking, ZFS, jails, and documentation (Handbook).',
      install: 'ISO: https://www.freebsd.org/where/\n\nVirtualBox: FreeBSD (64-bit), bsdinstall is clear.\nHandbook: https://docs.freebsd.org/en/books/handbook/\n\nTermux: not FreeBSD; different kernel.',
      tags: ['BSD', 'ZFS', 'Jails', 'Handbook']
    }
  };

  /* ===== DATA: TOOLS ===== */
  var toolData = {
    metasploit: {
      title: 'Metasploit Framework', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/metasploit/2596CD" width="28" height="28" alt="MSF">',
      base: 'Ruby', pm: 'apt / omnibus', use: 'Exploit dev & validation',
      desc: 'Industry-standard framework for developing, testing and validating exploits inside authorized labs and CTFs only. msfconsole is the main interface; modules cover exploits, payloads, post-exploitation and auxiliaries.',
      install: 'Linux (Kali/Debian/Ubuntu):\nsudo apt update && sudo apt install metasploit-framework\n# or official omnibus installer from Rapid7\n\nTermux:\npkg install unstable-repo\npkg install metasploit\n# or use proot Debian/Kali and install there\n\nWindows: official installer from rapid7.com (use only in lab VMs)\n\nAlways run inside isolated lab / authorized scope.',
      tags: ['Exploits', 'Payloads', 'Labs only', 'msfconsole']
    },
    burp: {
      title: 'Burp Suite', level: 'Advanced',
      icon: '<i class="fas fa-spider" style="color:#ff6633;font-size:26px;"></i>',
      base: 'Java', pm: 'Official installer', use: 'Web app testing',
      desc: 'Primary intercepting proxy for web application security testing. Intercept, modify, replay and fuzz HTTP/S traffic. Community edition is free and powerful; Pro adds scanner and more.',
      install: 'All OS (official):\nhttps://portswigger.net/burp/communitydownload\nRequires Java 17+ or bundled JRE.\n\nLinux: download .sh or .jar, chmod +x, run.\n\nTermux: limited (no full GUI). Use proot Ubuntu/Debian + install Burp, or use alternative CLI proxies. For mobile testing prefer real desktop or remote Burp.\n\nWindows / macOS: official installer.',
      tags: ['Proxy', 'Repeater', 'Intruder', 'Extensions']
    },
    nmap: {
      title: 'Nmap', level: 'Advanced',
      icon: '<i class="fas fa-magnifying-glass" style="color:#00e5ff;font-size:26px;"></i>',
      base: 'C / NSE', pm: 'apt / pkg', use: 'Network discovery',
      desc: 'Essential network mapper: host discovery, port scanning, version detection, OS fingerprinting and NSE scripting. Foundation of almost every recon phase.',
      install: 'Linux (Debian/Ubuntu/Kali):\nsudo apt update && sudo apt install nmap\n\nFedora/RHEL: sudo dnf install nmap\n\nTermux:\npkg install nmap\n\nWindows: official installer from nmap.org (includes Zenmap GUI)\n\nQuick example: nmap -sV -sC -oA scan target',
      tags: ['Ports', 'NSE', 'Recon', 'Service detect']
    },
    wireshark: {
      title: 'Wireshark', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/wireshark/1679A7" width="28" height="28" alt="Wireshark">',
      base: 'C / Qt', pm: 'apt / pkg', use: 'Packet analysis',
      desc: 'Deep packet inspection for protocols, debugging, and lab traffic analysis. tshark is the CLI counterpart for scripting and headless use.',
      install: 'Linux: sudo apt install wireshark\n# add user to wireshark group for non-root capture\n\nTermux: pkg install tshark (CLI) or use proot for full Wireshark\n\nWindows / macOS: official installer from wireshark.org\n\nAlways capture only on networks you own or have permission.',
      tags: ['PCAP', 'Protocols', 'tshark', 'Filters']
    },
    zap: {
      title: 'OWASP ZAP', level: 'Working',
      icon: '<img src="https://cdn.simpleicons.org/owasp/000000" width="28" height="28" alt="ZAP" style="filter:invert(1) opacity(.85)">',
      base: 'Java', pm: 'Official / apt', use: 'Web scanning',
      desc: 'Free and open-source web application scanner and proxy. Spider, passive/active scan, API testing and automation via ZAP API.',
      install: 'Linux: sudo apt install zaproxy\nor download from https://www.zaproxy.org/download/\n\nTermux: limited GUI. Prefer proot Ubuntu + install, or use ZAP in daemon mode from desktop.\n\nWindows / macOS: official installer.\nRequires Java.',
      tags: ['DAST', 'Spider', 'Active scan', 'Free']
    },
    sqlmap: {
      title: 'sqlmap', level: 'Working',
      icon: '<i class="fas fa-database" style="color:#f87171;font-size:26px;"></i>',
      base: 'Python', pm: 'apt / pip / git', use: 'SQL injection testing',
      desc: 'Automated SQL injection detection and exploitation tool for labs and authorized assessments only. Supports many DBMSes, tamper scripts and takeover techniques.',
      install: 'Linux: sudo apt install sqlmap\n# or: git clone https://github.com/sqlmapproject/sqlmap\n\nTermux:\npkg install python\npip install sqlmap\n# or git clone and run with python\n\nWindows: Python + git clone or pip install sqlmap\n\nAlways scope-limited and authorized only.',
      tags: ['SQLi', 'DB enum', 'Labs', 'Tamper']
    },
    john: {
      title: 'John the Ripper', level: 'Working',
      icon: '<i class="fas fa-key" style="color:#fbbf24;font-size:26px;"></i>',
      base: 'C', pm: 'apt / pkg', use: 'Password cracking',
      desc: 'Classic offline hash cracker. Supports many hash formats, rules and wordlists. Jumbo version adds extra formats. CTF and lab staple.',
      install: 'Linux: sudo apt install john\n# Jumbo recommended for more formats\n\nTermux: pkg install john\n\nWindows: official builds or WSL.\n\nPair with SecLists / rockyou wordlists.',
      tags: ['Hashes', 'Wordlists', 'Offline', 'CTF']
    },
    hydra: {
      title: 'Hydra', level: 'Working',
      icon: '<i class="fas fa-unlock-keyhole" style="color:#a78bfa;font-size:26px;"></i>',
      base: 'C', pm: 'apt / pkg', use: 'Online brute-force',
      desc: 'Fast multi-protocol logon cracker (SSH, FTP, HTTP, etc.). Use only against systems you own or have explicit written permission to test.',
      install: 'Linux: sudo apt install hydra\n\nTermux: pkg install hydra\n\nWindows: limited native; prefer WSL or Linux VM.\n\nAlways combine with rate limits and authorization.',
      tags: ['Brute-force', 'SSH/FTP/HTTP', 'Authorized only']
    },
    ghidra: {
      title: 'Ghidra', level: 'Basics',
      icon: '<i class="fas fa-diagram-project" style="color:#22d3ee;font-size:26px;"></i>',
      base: 'Java', pm: 'Official NSA', use: 'Reverse engineering',
      desc: 'NSA open-source reverse-engineering framework: disassembler + decompiler. Excellent for binary CTF tracks and malware analysis labs.',
      install: 'All OS: https://ghidra-sre.org/\nRequires JDK 17+.\nUnzip → run ghidraRun (Linux/macOS) or ghidraRun.bat (Windows).\n\nTermux: heavy; better to use proot Ubuntu + install JDK + Ghidra, or analyze on desktop.\n\nLinux: also available in some repos or as flatpak.',
      tags: ['Disasm', 'Decompiler', 'Binary RE', 'CTF']
    },
    nikto: {
      title: 'Nikto', level: 'Working',
      icon: '<i class="fas fa-shield-halved" style="color:#34d399;font-size:26px;"></i>',
      base: 'Perl', pm: 'apt / pkg', use: 'Web server scan',
      desc: 'Quick web server scanner for outdated software, dangerous files, misconfigurations and common vulnerabilities. Good first-pass recon tool.',
      install: 'Linux: sudo apt install nikto\n\nTermux: pkg install nikto\n\nWindows: Perl + download from GitHub (sullo/nikto).\n\nExample: nikto -h https://target',
      tags: ['Web scan', 'Misconfig', 'Recon']
    },
    hashcat: {
      title: 'Hashcat', level: 'Working',
      icon: '<i class="fas fa-lock" style="color:#f472b6;font-size:26px;"></i>',
      base: 'C / OpenCL', pm: 'apt / pkg', use: 'GPU password cracking',
      desc: 'World\'s fastest password recovery tool. GPU-accelerated attack modes for hundreds of hash types. CTF and lab staple for offline hashes.',
      install: 'Linux:\nsudo apt install hashcat\n\nTermux:\npkg install hashcat\n\nExample: hashcat -m 0 hashes.txt rockyou.txt',
      tags: ['GPU', 'Offline', 'Masks', 'Rules', 'CTF']
    },
    aircrack: {
      title: 'Aircrack-ng', level: 'Working',
      icon: '<i class="fas fa-wifi" style="color:#38bdf8;font-size:26px;"></i>',
      base: 'C', pm: 'apt', use: 'Wireless auditing',
      desc: 'Complete suite for Wi-Fi security assessment: monitor mode, packet capture, WEP/WPA cracking. Requires compatible wireless card. Authorized networks only.',
      install: 'Linux:\nsudo apt install aircrack-ng airgeddon wifite reaver bully\n\nNeeds monitor-mode capable Wi-Fi card.',
      tags: ['Wi-Fi', 'WPA', 'Handshake', 'Monitor mode']
    },
    gobuster: {
      title: 'Gobuster', level: 'Working',
      icon: '<i class="fas fa-folder-open" style="color:#a78bfa;font-size:26px;"></i>',
      base: 'Go', pm: 'apt / go', use: 'Directory & DNS brute',
      desc: 'Fast content discovery tool written in Go. Modes for directories, DNS subdomains, vhosts. Pairs well with SecLists.',
      install: 'Linux:\nsudo apt install gobuster\n\nTermux: pkg install gobuster\n\nExample: gobuster dir -u https://target -w /usr/share/wordlists/dirb/common.txt',
      tags: ['Dir brute', 'DNS', 'Vhost', 'Fast']
    },
    ffuf: {
      title: 'ffuf', level: 'Working',
      icon: '<i class="fas fa-search" style="color:#fbbf24;font-size:26px;"></i>',
      base: 'Go', pm: 'apt / go', use: 'Web fuzzer',
      desc: 'Extremely fast web fuzzer. Directory discovery, parameter fuzzing, virtual host discovery. Highly configurable filters.',
      install: 'Linux:\nsudo apt install ffuf\n\nTermux: pkg install ffuf\n\nExample: ffuf -u https://target/FUZZ -w wordlist.txt',
      tags: ['Fuzzing', 'Fast', 'Filters', 'Web']
    },
    nuclei: {
      title: 'Nuclei', level: 'Working',
      icon: '<i class="fas fa-bolt" style="color:#f87171;font-size:26px;"></i>',
      base: 'Go', pm: 'apt / go', use: 'Template-based scanning',
      desc: 'Fast vulnerability scanner powered by community templates. Detects known CVEs, misconfigurations, exposed panels.',
      install: 'Linux:\nsudo apt install nuclei\n\nnuclei -update-templates\n\nTermux: pkg install nuclei',
      tags: ['Templates', 'CVE', 'Fast', 'ProjectDiscovery']
    },
    amass: {
      title: 'OWASP Amass', level: 'Working',
      icon: '<i class="fas fa-satellite" style="color:#22d3ee;font-size:26px;"></i>',
      base: 'Go', pm: 'apt / go', use: 'Attack surface mapping',
      desc: 'In-depth subdomain enumeration and network mapping. Combines passive OSINT with active techniques.',
      install: 'Linux:\nsudo apt install amass\n\nTermux: pkg install amass\n\nExample: amass enum -d target.com',
      tags: ['Subdomains', 'OSINT', 'DNS', 'Mapping']
    },
    bloodhound: {
      title: 'BloodHound', level: 'Working',
      icon: '<i class="fas fa-sitemap" style="color:#fb923c;font-size:26px;"></i>',
      base: 'Neo4j + Electron', pm: 'apt', use: 'AD attack path analysis',
      desc: 'Maps Active Directory relationships and finds shortest paths to Domain Admin. Collect with SharpHound, analyze in GUI.',
      install: 'Linux:\nsudo apt install bloodhound\n\nRequires Neo4j running. Collectors: SharpHound / AzureHound.',
      tags: ['Active Directory', 'Attack paths', 'Graph']
    },
    netexec: {
      title: 'NetExec (nxc)', level: 'Working',
      icon: '<i class="fas fa-network-wired" style="color:#4ade80;font-size:26px;"></i>',
      base: 'Python', pm: 'apt / pip', use: 'Network execution & AD',
      desc: 'Successor to CrackMapExec. Spray credentials, execute commands, dump secrets, enumerate shares — authorized labs only.',
      install: 'Linux:\nsudo apt install netexec\n\nExample: nxc smb 192.168.1.0/24 -u user -p pass',
      tags: ['AD', 'SMB', 'Spray', 'Lateral']
    },
    responder: {
      title: 'Responder', level: 'Working',
      icon: '<i class="fas fa-broadcast-tower" style="color:#e879f9;font-size:26px;"></i>',
      base: 'Python', pm: 'apt', use: 'LLMNR/NBT-NS poisoning',
      desc: 'Poison LLMNR, NBT-NS and MDNS to capture NetNTLM hashes on Windows networks. Authorized internal assessments only.',
      install: 'Linux:\nsudo apt install responder\n\nExample: sudo responder -I eth0 -wv',
      tags: ['Poisoning', 'NetNTLM', 'Internal']
    },
    bettercap: {
      title: 'Bettercap', level: 'Working',
      icon: '<i class="fas fa-project-diagram" style="color:#60a5fa;font-size:26px;"></i>',
      base: 'Go', pm: 'apt', use: 'Network attacks & MITM',
      desc: 'Modern modular network attack framework. ARP spoofing, DNS spoofing, HTTP/HTTPS proxy, Wi-Fi, BLE and more.',
      install: 'Linux:\nsudo apt install bettercap\n\nStart: sudo bettercap',
      tags: ['MITM', 'ARP', 'Proxy', 'Modular']
    },
    radare2: {
      title: 'Radare2', level: 'Basics',
      icon: '<i class="fas fa-microchip" style="color:#94a3b8;font-size:26px;"></i>',
      base: 'C', pm: 'apt', use: 'Reverse engineering',
      desc: 'Powerful open-source reverse-engineering framework. Disassembler, debugger, binary analysis. Rizin is a fork; Cutter is the GUI.',
      install: 'Linux:\nsudo apt install radare2 rizin cutter\n\nStart: r2 binary',
      tags: ['RE', 'Disasm', 'Debugger', 'CTF']
    },
    masscan: {
      title: 'Masscan', level: 'Working',
      icon: '<i class="fas fa-tachometer-alt" style="color:#facc15;font-size:26px;"></i>',
      base: 'C', pm: 'apt', use: 'Ultra-fast port scan',
      desc: 'Internet-scale port scanner. Can scan large ranges very quickly. Use only on authorized targets.',
      install: 'Linux:\nsudo apt install masscan\n\nExample: masscan -p80,443 10.0.0.0/8 --rate 1000',
      tags: ['Port scan', 'Fast', 'Large scope']
    },
    wpscan: {
      title: 'WPScan', level: 'Working',
      icon: '<i class="fab fa-wordpress" style="color:#38bdf8;font-size:26px;"></i>',
      base: 'Ruby', pm: 'apt / gem', use: 'WordPress scanner',
      desc: 'Black-box WordPress vulnerability scanner. Enumerates users, plugins, themes and checks known vulnerabilities.',
      install: 'Linux:\nsudo apt install wpscan\n\nwpscan --update\nwpscan --url https://target --enumerate u,p,t',
      tags: ['WordPress', 'CMS', 'Plugins', 'Enum']
    },
    enum4linux: {
      title: 'Enum4linux', level: 'Working',
      icon: '<i class="fas fa-server" style="color:#a3e635;font-size:26px;"></i>',
      base: 'Perl', pm: 'apt', use: 'SMB / Windows enum',
      desc: 'Wrapper around Samba tools for enumerating Windows and Samba hosts: users, shares, password policies, OS info.',
      install: 'Linux:\nsudo apt install enum4linux\n\nExample: enum4linux -a 192.168.1.10',
      tags: ['SMB', 'Windows', 'Shares', 'Users']
    }
  };

  /* ===== DETAIL MODAL ===== */
  var detailOverlay = document.getElementById('distro-overlay');
  var lastFocused = null;

  function openDetailModal(key, map) {
    var d = map[key];
    if (!d) { console.warn('No data for key:', key); return; }
    if (!detailOverlay) { console.warn('Modal overlay not found'); return; }
    var iconEl = document.getElementById('distro-modal-icon');
    var titleEl = document.getElementById('distro-modal-title');
    var levelEl = document.getElementById('distro-modal-level');
    var descEl = document.getElementById('distro-modal-desc');
    var baseEl = document.getElementById('distro-modal-base');
    var pmEl = document.getElementById('distro-modal-pm');
    var useEl = document.getElementById('distro-modal-use');
    var tagsEl = document.getElementById('distro-modal-tags');
    var installEl = document.getElementById('distro-modal-install');

    if (iconEl) iconEl.innerHTML = d.icon || '';
    if (titleEl) titleEl.textContent = d.title || '';
    if (levelEl) levelEl.textContent = d.level || '';
    if (descEl) descEl.textContent = d.desc || '';
    if (baseEl) baseEl.textContent = d.base || '';
    if (pmEl) pmEl.textContent = d.pm || '';
    if (useEl) useEl.textContent = d.use || '';

    if (installEl) {
      if (d.install) {
        installEl.style.display = 'block';
        var html = String(d.install).replace(/\n/g, '<br>');
        // make http(s) URLs clickable via site redirect
        html = html.replace(/(https?:\/\/[^\s<]+)/g, function (url) {
          return '<a href="redirect.html?url=' + encodeURIComponent(url) + '" style="color:#00e5ff;text-decoration:underline;">' + url + '</a>';
        });
        installEl.innerHTML = '<span>Install / setup (Linux · VM · Termux)</span>' + html;
      } else {
        installEl.style.display = 'none';
        installEl.innerHTML = '';
      }
    }

    if (tagsEl) {
      tagsEl.innerHTML = '';
      (d.tags || []).forEach(function (t) {
        var s = document.createElement('span');
        s.textContent = t;
        tagsEl.appendChild(s);
      });
    }

    detailOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function () { detailOverlay.classList.add('visible'); });
  }

  function closeDetailModal() {
    if (!detailOverlay || !detailOverlay.classList.contains('open')) return;
    detailOverlay.classList.remove('visible');
    document.body.style.overflow = '';
    setTimeout(function () {
      detailOverlay.classList.remove('open');
      if (lastFocused) lastFocused.focus();
    }, 250);
  }

  document.querySelectorAll('.distro-card').forEach(function (card) {
    function open() {
      lastFocused = card;
      openDetailModal(card.getAttribute('data-distro'), distroData);
    }
    card.addEventListener('click', open);
    card.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
    });
  });

  document.querySelectorAll('.tool-card').forEach(function (card) {
    function open() {
      lastFocused = card;
      openDetailModal(card.getAttribute('data-tool'), toolData);
    }
    card.addEventListener('click', open);
    card.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
    });
  });

  if (detailOverlay) {
    detailOverlay.addEventListener('click', function (e) {
      if (e.target === detailOverlay) closeDetailModal();
    });
  }
  var closeBtn = document.getElementById('distro-modal-close');
  if (closeBtn) closeBtn.addEventListener('click', closeDetailModal);

  /* ===== DYNAMIC REVEAL (IntersectionObserver + stagger) ===== */
  (function initReveals() {
    var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var nodes = document.querySelectorAll('.reveal');
    if (!nodes.length) return;

    if (prefersReduced || !('IntersectionObserver' in window)) {
      nodes.forEach(function (el) { el.classList.add('visible'); });
      return;
    }

    // Group by parent for staggered children
    var groups = new Map();
    nodes.forEach(function (el) {
      var parent = el.parentElement || document.body;
      if (!groups.has(parent)) groups.set(parent, []);
      groups.get(parent).push(el);
    });

    groups.forEach(function (list) {
      list.forEach(function (el, index) {
        var delay = Math.min(index * 70, 420); // max ~420ms stagger
        el.style.setProperty('--delay', delay + 'ms');
        el.setAttribute('data-delay', delay);
      });
    });

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          io.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      rootMargin: '0px 0px -8% 0px',
      threshold: 0.08
    });

    nodes.forEach(function (el) { io.observe(el); });

    // Immediate check for above-the-fold
    requestAnimationFrame(function () {
      nodes.forEach(function (el) {
        var rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.92 && rect.bottom > 0) {
          el.classList.add('visible');
          io.unobserve(el);
        }
      });
    });
  })();

  /* ===== EXTRA DYNAMIC TOUCHES ===== */
  // Soft float on selected decorative icons (home / about)
  document.querySelectorAll('.hero-badge, .about-image-frame, .ex-icon').forEach(function (el, i) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    el.classList.add(i % 2 === 0 ? 'anim-float-soft' : 'anim-float');
    el.style.animationDelay = (i * 0.35) + 's';
  });

  // Subtle glow pulse on primary buttons when idle
  document.querySelectorAll('.btn-primary').forEach(function (btn) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    btn.classList.add('anim-glow');
  });

  console.log('%cCPS ready · Dynamic animations ON', 'color:#00e5ff;font-weight:bold;');
})();


  (function initSearch() {
    var pages = [
      { t: "Home", d: "Cyber Prime Squad \u00b7 Ethical hacking team", u: "index.html", i: "fa-home" },
      { t: "CPS AI", d: "Powerful AI chat \u00b7 Image gen", u: "cps-ai.html", i: "fa-robot" },
      { t: "Skills", d: "Languages \u00b7 Linux \u00b7 Security tools", u: "skills.html", i: "fa-code" },
      { t: "OS Guide", d: "Kali \u00b7 Arch \u00b7 Debian \u00b7 Termux install", u: "os-install.html", i: "fa-download" },
      { t: "Resources", d: "Guides \u00b7 links \u00b7 notes", u: "resources.html", i: "fa-book" },
      { t: "Contact", d: "Email \u00b7 WhatsApp \u00b7 Telegram \u00b7 Discord", u: "contact.html", i: "fa-envelope" },
      { t: "Tools", d: "Nmap \u00b7 Burp \u00b7 Metasploit \u00b7 install guides", u: "tools.html", i: "fa-toolbox" },
      { t: "Recon", d: "Passive \u00b7 Active \u00b7 OSINT methodology", u: "recon.html", i: "fa-satellite" },
      { t: "Toolkit", d: "Password \u00b7 AES \u00b7 Hash \u00b7 QR \u00b7 Base64 tools", u: "toolkit.html", i: "fa-key" },
      { t: "OSINT Lab", d: "URL \u00b7 IP \u00b7 Email \u00b7 MAC \u00b7 Phone OSINT scans", u: "osint-lab.html", i: "fa-satellite-dish" },
      { t: "Code Editor", d: "In-browser code tools \u00b7 HTML/CSS/JS", u: "code-editor.html", i: "fa-code" },
      { t: "Interests", d: "Topics we care about", u: "interests.html", i: "fa-heart" },
      { t: "SMM", d: "Social media panels", u: "smm.html", i: "fa-bullhorn" },
      { t: "FB DP", d: "Facebook profile picture download", u: "facebook-dp-downloader.html", i: "fa-facebook" },
      { t: "Portrait", d: "Random portrait generator", u: "random-portrait.html", i: "fa-user-circle" },
      { t: "Temp Mail", d: "Disposable email for testing", u: "temp-mail.html", i: "fa-envelope-open-text" },
      { t: "Weather", d: "World weather explorer", u: "sayan-weather.html", i: "fa-cloud-sun" },
      { t: "Spamming", d: "Analysis \u00b7 awareness", u: "spamming.html", i: "fa-user-secret" },
      { t: "SQLi", d: "SQL injection guide", u: "sqli.html", i: "fa-database" },
      { t: "XSS", d: "Cross-site scripting guide", u: "xss.html", i: "fa-code" },
      { t: "CPS Image", d: "Upload \u00b7 Host \u00b7 Share", u: "tcf-image.html", i: "fa-images" },
      { t: "BG Remover", d: "Remove image backgrounds", u: "bg-remover.html", i: "fa-eraser" },
      { t: "YT Thumbnail", d: "Download HD YouTube thumbnails", u: "yt-thumbnail.html", i: "fa-youtube" },
      { t: "Video", d: "HD video & MP3 downloader", u: "video.html", i: "fa-video" },
      { t: "TikTok", d: "Video & audio downloader", u: "tiktok.html", i: "fa-music" },
      { t: "Repeater", d: "Text repeater tool", u: "repeater.html", i: "fa-repeat" },
      { t: "Explorer", d: "HD \u00b7 4K \u00b7 8K images", u: "explorer.html", i: "fa-compass" },
      { t: "Additional", d: "Report message templates", u: "additional.html", i: "fa-file-alt" },
      { t: "FF", d: "Free Fire market value", u: "tcf-ff-market-value.html", i: "fa-gem" },
      { t: "CPS System", d: "System interface \u00b7 Matrix", u: "jh-system.html", i: "fa-terminal" },
      { t: "Stenographer", d: "Hide secret text in pictures", u: "stenographer.html", i: "fa-eye-slash" }
    ];
    var navContainer = document.querySelector('.nav-container');
    if (!navContainer) return;
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'nav-search-btn'; btn.id = 'nav-search-btn';
    btn.setAttribute('aria-label', 'Search pages');
    btn.innerHTML = '<i class="fas fa-search"></i>';
    var toggle = document.getElementById('nav-toggle');
    if (toggle && toggle.parentNode) toggle.parentNode.insertBefore(btn, toggle);
    else navContainer.appendChild(btn);

    var overlay = document.createElement('div');
    overlay.className = 'search-overlay'; overlay.id = 'search-overlay';
    overlay.innerHTML = '<div class="search-box"><input type="search" id="site-search-input" placeholder="Search pages… (Ctrl+K)" autocomplete="off" /><div class="search-results" id="site-search-results"></div></div>';
    document.body.appendChild(overlay);

    var input = overlay.querySelector('#site-search-input');
    var results = overlay.querySelector('#site-search-results');
    var activeIdx = -1;

    function openSearch() {
      overlay.classList.add('open');
      setTimeout(function(){ input.focus(); input.select(); }, 50);
      render('');
    }
    function closeSearch() {
      overlay.classList.remove('open');
      activeIdx = -1;
    }
    function render(q) {
      q = (q || '').toLowerCase().trim();
      var list = pages.filter(function(p) {
        return !q || p.t.toLowerCase().indexOf(q) >= 0 || p.d.toLowerCase().indexOf(q) >= 0;
      });
      results.innerHTML = list.map(function(p, i) {
        return '<a class="search-result" href="' + p.u + '" data-idx="' + i + '"><i class="fas ' + p.i + '"></i><div><div class="sr-title">' + p.t + '</div><div class="sr-desc">' + p.d + '</div></div></a>';
      }).join('') || '<div style="padding:12px;color:rgba(255,255,255,.4);font-size:13px;">No matches</div>';
      activeIdx = -1;
    }
    btn.addEventListener('click', openSearch);
    overlay.addEventListener('click', function(e){ if (e.target === overlay) closeSearch(); });
    input.addEventListener('input', function(){ render(input.value); });
    document.addEventListener('keydown', function(e) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openSearch(); }
      if (e.key === 'Escape' && overlay.classList.contains('open')) closeSearch();
    });
  })();
